/* 南山无障碍地图 - 前端逻辑（Leaflet 免 key 演示模式） */
/* 南山区中心坐标 (GCJ-02，与高德瓦片一致) */
const NANSHAN_CENTER = [22.53291, 113.93029];

const STATUS_TEXT = { pending: '待处理', processing: '处理中', resolved: '已解决' };
const STATUS_CLS = { pending: 'status-pending', processing: 'status-processing', resolved: 'status-resolved' };
const PIN_CLS = { pending: 'pin-pending', processing: 'pin-processing', resolved: 'pin-resolved' };

let map;
let reports = [];
let markers = [];           // 当前地图上的 marker
let currentFilter = 'all';
let currentDetail = null;   // 详情面板当前展示的上报
let pickMode = false;       // 是否处于地图选点模式
let formLoc = null;         // 表单当前定位 {lat, lng, address}
let pickMarker = null;      // 手动选点的临时标记（提交成功后由正式标记替代）

/* 身份：public 公众（只可上报） | volunteer 志愿者组织（上报+处理+反馈） */
let me = null;               // 当前登录用户 { username, role, orgName }
let token = localStorage.getItem('am_token') || null;

/* 大字模式 */
let bigText = localStorage.getItem('am_bigtext') === '1';

const $ = id => document.getElementById(id);

function authHeaders(json) {
  return {
    ...(json ? { 'Content-Type': 'application/json' } : {}),
    ...(token ? { Authorization: 'Bearer ' + token } : {})
  };
}

/* ---------------- 初始化地图 ---------------- */
map = L.map('map', {
  center: NANSHAN_CENTER,
  zoom: 13,
  zoomControl: true,
  attributionControl: false
});

/* 高德公开瓦片（免 key，GCJ-02 坐标系） */
L.tileLayer('https://webrd0{s}.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}', {
  subdomains: ['1', '2', '3', '4'],
  maxZoom: 18
}).addTo(map);

map.on('click', e => {
  if (!pickMode) return;
  handleMapPick(e.latlng);
});

/* ---------------- 手动选点：临时标记 ----------------
   样式/尺寸/锚点与 renderMarkers 中的「待处理」障碍标记完全一致
   （.pin .pin-pending .pin-pulse，26×26，anchor [13,26]），
   interactive:false 使点击穿透，连续点击可即时修正位置 */
function showPickMarker(lat, lng) {
  const icon = L.divIcon({
    className: '',
    html: '<div class="pin pin-pending pin-pulse"></div>',
    iconSize: [26, 26],
    iconAnchor: [13, 26]
  });
  if (!pickMarker) {
    pickMarker = L.marker([lat, lng], { icon, interactive: false, keyboard: false }).addTo(map);
  } else {
    pickMarker.setLatLng([lat, lng]); // 已存在则实时跟随点击位置，无延迟
  }
}

function clearPickMarker() {
  if (pickMarker) {
    map.removeLayer(pickMarker);
    pickMarker = null;
  }
}

/* 选点模式下点击地图（或点中已有障碍标记）的统一入口 */
function handleMapPick(latlng) {
  const lat = latlng.lat;
  const lng = latlng.lng;
  showPickMarker(lat, lng);      // 立即在点击位置渲染临时标记
  setFormLocation(lat, lng, ''); // 记录坐标并解析地址
  exitPickMode();
  openSheet('reportSheet');      // 回到上报表单继续填写信息
}

bindUI();
applyBigText();
refresh();

/* 每 10 秒轮询一次，实现多用户准实时同步 */
setInterval(refresh, 10000);

/* 首次进入：尝试恢复登录态，未登录则弹登录框 */
initAuth();

/* ---------------- 坐标转换（GPS 的 WGS84 → 高德瓦片的 GCJ-02） ---------------- */
function transformLat(x, y) {
  let ret = -100.0 + 2.0 * x + 3.0 * y + 0.2 * y * y + 0.1 * x * y + 0.2 * Math.sqrt(Math.abs(x));
  ret += (20.0 * Math.sin(6.0 * x * Math.PI) + 20.0 * Math.sin(2.0 * x * Math.PI)) * 2.0 / 3.0;
  ret += (20.0 * Math.sin(y * Math.PI) + 40.0 * Math.sin(y / 3.0 * Math.PI)) * 2.0 / 3.0;
  ret += (160.0 * Math.sin(y / 12.0 * Math.PI) + 320.0 * Math.sin(y * Math.PI / 30.0)) * 2.0 / 3.0;
  return ret;
}
function transformLng(x, y) {
  let ret = 300.0 + x + 2.0 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * Math.sqrt(Math.abs(x));
  ret += (20.0 * Math.sin(6.0 * x * Math.PI) + 20.0 * Math.sin(2.0 * x * Math.PI)) * 2.0 / 3.0;
  ret += (20.0 * Math.sin(x * Math.PI) + 40.0 * Math.sin(x / 3.0 * Math.PI)) * 2.0 / 3.0;
  ret += (150.0 * Math.sin(x / 12.0 * Math.PI) + 300.0 * Math.sin(x / 30.0 * Math.PI)) * 2.0 / 3.0;
  return ret;
}
function wgs84ToGcj02(lat, lng) {
  const a = 6378245.0, ee = 0.00669342162296594323;
  if (lng < 72.004 || lng > 137.8347 || lat < 0.8293 || lat > 55.8271) return [lat, lng];
  let dLat = transformLat(lng - 105.0, lat - 35.0);
  let dLng = transformLng(lng - 105.0, lat - 35.0);
  const radLat = lat / 180.0 * Math.PI;
  let magic = Math.sin(radLat);
  magic = 1 - ee * magic * magic;
  const sqrtMagic = Math.sqrt(magic);
  dLat = (dLat * 180.0) / ((a * (1 - ee)) / (magic * sqrtMagic) * Math.PI);
  dLng = (dLng * 180.0) / (a / sqrtMagic * Math.cos(radLat) * Math.PI);
  return [lat + dLat, lng + dLng];
}

/* ---------------- 逆地理编码（Nominatim 免费服务，失败则回退坐标） ---------------- */
async function regeoAddress(lat, lng) {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}&zoom=18&accept-language=zh-CN`,
      { headers: { 'Accept': 'application/json' } }
    );
    if (!res.ok) return '';
    const data = await res.json();
    return data.display_name || '';
  } catch {
    return '';
  }
}

/* ---------------- 大字模式 ---------------- */
function applyBigText() {
  document.body.classList.toggle('big-text', bigText);
  $('btnLargeText').classList.toggle('big-text-on', bigText);
  $('btnLargeText').title = bigText ? '关闭大字模式' : '开启大字模式';
}

/* ---------------- UI 绑定 ---------------- */
function bindUI() {
  // 大字模式切换
  $('btnLargeText').addEventListener('click', () => {
    bigText = !bigText;
    localStorage.setItem('am_bigtext', bigText ? '1' : '0');
    applyBigText();
  });

  // 筛选
  document.querySelectorAll('.chip').forEach(chip => {
    chip.addEventListener('click', () => {
      document.querySelectorAll('.chip').forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      currentFilter = chip.dataset.filter;
      renderMarkers();
    });
  });

  $('btnLocate').addEventListener('click', locateMe);
  $('btnReport').addEventListener('click', openReportSheet);
  $('btnPickOnMap').addEventListener('click', enterPickMode);
  $('btnCancelPick').addEventListener('click', () => { exitPickMode(); openSheet('reportSheet'); });
  $('btnCloseReport').addEventListener('click', closeAllSheets);
  $('btnCloseDetail').addEventListener('click', closeAllSheets);
  $('sheetMask').addEventListener('click', closeAllSheets);

  // 账号入口
  $('roleBadge').addEventListener('click', openAuthModal);
  $('tabLogin').addEventListener('click', () => switchAuthTab('login'));
  $('tabRegister').addEventListener('click', () => switchAuthTab('register'));
  $('regPublic').addEventListener('click', () => setRegRole('public'));
  $('regVolunteer').addEventListener('click', () => setRegRole('volunteer'));
  $('authSubmit').addEventListener('click', submitAuth);
  $('authSwitch').addEventListener('click', () => switchAuthTab('register'));

  // 我的足迹
  $('btnFootprints').addEventListener('click', openFootprints);
  $('btnCloseFootprints').addEventListener('click', closeAllSheets);

  // 解决结果反馈
  $('resolvePhotoInput').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    $('resolvePreview').src = URL.createObjectURL(file);
    $('resolvePreview').classList.remove('hidden');
    $('resolveHint').classList.add('hidden');
  });
  $('btnSubmitResolve').addEventListener('click', submitResolve);
  $('btnCloseResolve').addEventListener('click', closeAllSheets);

  $('photoInput').addEventListener('change', e => {
    const file = e.target.files[0];
    if (!file) return;
    const url = URL.createObjectURL(file);
    const preview = $('photoPreview');
    preview.src = url;
    preview.classList.remove('hidden');
    $('photoHint').classList.add('hidden');
  });

  $('btnSubmit').addEventListener('click', submitReport);

  // 照片点击查看大图
  ['dPhoto', 'dResPhoto'].forEach(id => {
    $(id).addEventListener('click', () => {
      const src = $(id).getAttribute('src');
      if (src) openLightbox(src);
    });
  });
  $('btnCloseLightbox').addEventListener('click', closeLightbox);
  $('lightbox').addEventListener('click', e => { if (e.target === $('lightbox')) closeLightbox(); });
}

/* ---------------- 数据加载与渲染 ---------------- */
async function refresh() {
  try {
    const res = await fetch('/api/reports');
    reports = await res.json();
    renderMarkers();
    renderStats();
    if (currentDetail) {
      const latest = reports.find(r => r.id === currentDetail.id);
      if (latest) { currentDetail = latest; renderDetail(); }
    }
  } catch (e) {
    console.error('加载数据失败', e);
  }
}

function renderStats() {
  const p = reports.filter(r => r.status === 'pending').length;
  const g = reports.filter(r => r.status === 'processing').length;
  const d = reports.filter(r => r.status === 'resolved').length;
  $('stats').textContent = `共 ${reports.length} 条上报 · 待处理 ${p} · 处理中 ${g} · 已解决 ${d}`;
}

function filteredReports() {
  return currentFilter === 'all' ? reports : reports.filter(r => r.status === currentFilter);
}

function renderMarkers() {
  markers.forEach(m => map.removeLayer(m));
  markers = [];
  filteredReports().forEach(r => {
    const pulse = r.status === 'pending' ? ' pin-pulse' : '';
    const icon = L.divIcon({
      className: '',
      html: `<div class="pin ${PIN_CLS[r.status]}${pulse}"></div>`,
      iconSize: [26, 26],
      iconAnchor: [13, 26]
    });
    const marker = L.marker([r.lat, r.lng], { icon, title: r.category }).addTo(map);
    marker.on('click', () => {
      // 选点模式下点中已有障碍标记：在该位置完成选点，不打开详情（不影响正常模式下的查看/编辑）
      if (pickMode) { handleMapPick(marker.getLatLng()); return; }
      currentDetail = r; renderDetail(); openSheet('detailSheet');
    });
    markers.push(marker);
  });
}

/* ---------------- 定位（HTML5 Geolocation，本地 localhost 无需 HTTPS） ---------------- */
function locateMe() {
  if (!navigator.geolocation) { toast('当前浏览器不支持定位'); return; }
  toast('定位中…');
  navigator.geolocation.getCurrentPosition(
    pos => {
      // GPS 原始坐标是 WGS84，需转成 GCJ-02 才能与高德瓦片对齐
      const [lat, lng] = wgs84ToGcj02(pos.coords.latitude, pos.coords.longitude);
      map.setView([lat, lng], 16);
      toast('已定位到你的位置');
    },
    () => toast('定位失败，请检查权限或使用地图选点'),
    { enableHighAccuracy: true, timeout: 10000 }
  );
}

/* ---------------- 上报流程 ---------------- */
function openReportSheet() {
  if (!me) { toast('请先登录后再上报'); openAuthModal(); return; }
  clearPickMarker();
  $('photoInput').value = '';
  $('photoPreview').classList.add('hidden');
  $('photoHint').classList.remove('hidden');
  $('description').value = '';
  $('category').selectedIndex = 0;
  formLoc = null;
  $('locText').textContent = '定位中…';

  openSheet('reportSheet');

  if (!navigator.geolocation) {
    $('locText').textContent = '当前浏览器不支持定位，请点击「地图选点」手动选择位置';
    return;
  }
  navigator.geolocation.getCurrentPosition(async pos => {
    const [lat, lng] = wgs84ToGcj02(pos.coords.latitude, pos.coords.longitude);
    $('locText').textContent = '📍 已获取坐标，正在解析地址…';
    const address = await regeoAddress(lat, lng);
    setFormLocation(lat, lng, address);
  }, () => {
    $('locText').textContent = '定位失败，请点击「地图选点」手动选择位置';
  }, { enableHighAccuracy: true, timeout: 10000 });
}

function setFormLocation(lat, lng, address) {
  formLoc = { lat, lng, address: address || formLoc?.address || '' };
  $('locText').textContent = '📍 ' + (formLoc.address || `${lat.toFixed(6)}, ${lng.toFixed(6)}`);
  if (!formLoc.address) {
    regeoAddress(lat, lng).then(addr => {
      if (addr && formLoc) { formLoc.address = addr; $('locText').textContent = '📍 ' + addr; }
    });
  }
}

function enterPickMode() {
  pickMode = true;
  closeSheetBodies();
  $('sheetMask').classList.add('hidden');
  $('pickBar').classList.remove('hidden');
  // 再次进入选点时，回显已选位置的临时标记，便于在其基础上修正
  if (formLoc) showPickMarker(formLoc.lat, formLoc.lng);
}

function exitPickMode() {
  pickMode = false;
  $('pickBar').classList.add('hidden');
}

async function submitReport() {
  if (!formLoc) { toast('请先定位或使用地图选点'); return; }
  const file = $('photoInput').files[0];
  if (!file) { toast('请先拍照或选择照片'); return; }

  const btn = $('btnSubmit');
  btn.disabled = true;
  btn.textContent = '提交中…';
  try {
    const fd = new FormData();
    fd.append('photo', file);
    fd.append('lat', formLoc.lat);
    fd.append('lng', formLoc.lng);
    fd.append('address', formLoc.address);
    fd.append('category', $('category').value);
    fd.append('description', $('description').value.trim());

    const res = await fetch('/api/reports', { method: 'POST', headers: authHeaders(false), body: fd });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '提交失败');

    toast('上报成功，感谢你的贡献！');
    closeAllSheets();
    map.setView([data.lat, data.lng], 16);
    await refresh();
  } catch (e) {
    toast(e.message || '提交失败，请重试');
  } finally {
    btn.disabled = false;
    btn.textContent = '提交上报';
  }
}

/* ---------------- 详情与状态流转 ---------------- */
function renderDetail() {
  const r = currentDetail;
  if (!r) return;
  const photoEl = $('dPhoto');
  const fallback = $('dPhotoFallback');
  if (r.photo) {
    photoEl.src = r.photo;
    photoEl.classList.remove('hidden');
    fallback.classList.add('hidden');
  } else {
    photoEl.classList.add('hidden');
    fallback.classList.remove('hidden');
  }

  const badge = $('dStatus');
  badge.textContent = STATUS_TEXT[r.status];
  badge.className = 'status-badge ' + STATUS_CLS[r.status];
  $('dCategory').textContent = r.category;
  $('dDesc').textContent = r.description || '（无补充描述）';

  // 解决结果展示
  const resSec = $('dResolution');
  if (r.resolution) {
    resSec.classList.remove('hidden');
    if (r.resolution.photo) {
      $('dResPhoto').src = r.resolution.photo;
      $('dResPhoto').classList.remove('hidden');
    } else {
      $('dResPhoto').classList.add('hidden');
    }
    $('dResDesc').textContent = r.resolution.description;
    $('dResMeta').textContent = `✔ ${fmtTime(r.resolution.resolvedAt)}${r.resolution.operator ? ' · 处理方：' + r.resolution.operator : ''}`;
  } else {
    resSec.classList.add('hidden');
  }

  $('dAddr').textContent = '📍 ' + (r.address || `${r.lat.toFixed(6)}, ${r.lng.toFixed(6)}`);
  $('dTime').textContent = `上报时间：${fmtTime(r.createdAt)}`;

  $('dHistory').innerHTML = (r.history || [])
    .map(h => `<div>· ${STATUS_TEXT[h.status] || h.status}${h.operator ? '（' + h.operator + '）' : ''} — ${fmtTime(h.time)}</div>`).join('');

  const actions = $('dActions');
  actions.innerHTML = '';

  // 权限区分：公众只能查看，志愿者组织可处理
  if (!me || me.role !== 'volunteer') {
    const hint = document.createElement('p');
    hint.className = 'detail-time';
    hint.style.padding = '6px 0';
    hint.textContent = me
      ? '🙋 公众身份仅可查看与上报问题 · 处理需登录志愿者组织账号'
      : '请先登录以查看与处理问题';
    actions.appendChild(hint);
    return;
  }

  const addBtn = (cls, text, fn) => {
    const b = document.createElement('button');
    b.className = cls;
    b.textContent = text;
    b.addEventListener('click', fn);
    actions.appendChild(b);
  };
  if (r.status === 'pending') {
    addBtn('act-processing', '🔧 开始处理', () => updateStatus(r.id, 'processing'));
    addBtn('act-resolved', '✔ 标记已解决', () => openResolveSheet(r));
  } else if (r.status === 'processing') {
    addBtn('act-resolved', '✔ 标记已解决', () => openResolveSheet(r));
    addBtn('act-reopen', '退回待处理', () => updateStatus(r.id, 'pending'));
  } else {
    addBtn('act-reopen', '重新打开', () => updateStatus(r.id, 'pending'));
  }
}

async function updateStatus(id, status) {
  try {
    const res = await fetch(`/api/reports/${id}/status`, {
      method: 'PATCH',
      headers: authHeaders(true),
      body: JSON.stringify({ status })
    });
    if (!res.ok) throw new Error((await res.json()).error);
    toast('状态已更新');
    await refresh();
    closeAllSheets();
  } catch (e) {
    toast(e.message || '更新失败，请重试');
  }
}

/* ---------------- 解决结果反馈（仅志愿者组织） ---------------- */
function openResolveSheet(r) {
  $('resolvePhotoInput').value = '';
  $('resolvePreview').classList.add('hidden');
  $('resolveHint').classList.remove('hidden');
  $('solution').value = '';
  openSheet('resolveSheet');
}

async function submitResolve() {
  const r = currentDetail;
  if (!r) return;
  const file = $('resolvePhotoInput').files[0];
  const solution = $('solution').value.trim();
  if (!solution) { toast('请填写解决方案说明'); return; }

  const btn = $('btnSubmitResolve');
  btn.disabled = true;
  btn.textContent = '提交中…';
  try {
    const fd = new FormData();
    if (file) fd.append('photo', file);
    fd.append('solution', solution);
    const res = await fetch(`/api/reports/${r.id}/resolve`, {
      method: 'POST',
      headers: authHeaders(false),
      body: fd
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '提交失败');
    toast('已标记为已解决 🎉');
    closeAllSheets();
    await refresh();
  } catch (e) {
    toast(e.message || '提交失败，请重试');
  } finally {
    btn.disabled = false;
    btn.textContent = '提交解决结果';
  }
}

/* ---------------- 账号：登录 / 注册 ---------------- */
let authTab = 'login';      // login | register
let regRole = 'public';     // 注册身份

function openAuthModal() {
  $('authMask').classList.remove('hidden');
}

function closeAuthModal() {
  $('authMask').classList.add('hidden');
}

function switchAuthTab(tab) {
  authTab = tab;
  $('tabLogin').classList.toggle('active', tab === 'login');
  $('tabRegister').classList.toggle('active', tab === 'register');
  $('authSubmit').textContent = tab === 'login' ? '登录' : '注册';
  $('authSwitch').textContent = tab === 'login' ? '没有账号？去注册' : '已有账号？去登录';
  $('registerExtra').classList.toggle('hidden', tab !== 'register');
  $('loginPassword').value = ''; // 切换时清空密码，避免残留
}

function setRegRole(role) {
  regRole = role;
  $('regPublic').classList.toggle('selected', role === 'public');
  $('regVolunteer').classList.toggle('selected', role === 'volunteer');
}

async function submitAuth() {
  const username = $('loginUsername').value.trim();
  const password = $('loginPassword').value;
  if (!username) { toast('请输入用户名'); return; }
  if (!password) { toast('请输入密码'); return; }

  const btn = $('authSubmit');
  btn.disabled = true;
  try {
    const url = authTab === 'login' ? '/api/login' : '/api/register';
    const body = authTab === 'login'
      ? { username, password }
      : { username, password, role: regRole, orgName: $('regOrgName').value.trim() };

    const res = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || '操作失败');

    token = data.token;
    me = data.user;
    localStorage.setItem('am_token', token);
    updateRoleBadge();
    closeAuthModal();
    toast(authTab === 'login' ? `欢迎回来，${me.username}` : '注册成功，欢迎加入！');
    refresh();
  } catch (e) {
    toast(e.message || '操作失败');
  } finally {
    btn.disabled = false;
  }
}

async function initAuth() {
  if (!token) { openAuthModal(); return; }
  try {
    const res = await fetch('/api/me', { headers: authHeaders() });
    if (!res.ok) throw new Error();
    me = await res.json();
    updateRoleBadge();
  } catch {
    token = null; me = null;
    localStorage.removeItem('am_token');
    openAuthModal();
  }
}

function updateRoleBadge() {
  if (!me) { $('roleBadge').textContent = '未登录'; return; }
  $('roleBadge').textContent = me.role === 'volunteer'
    ? `🤝 ${me.orgName || me.username}`
    : `🙋 ${me.username}`;
}

/* ---------------- 我的足迹 ---------------- */
function openFootprints() {
  if (!me) { toast('请先登录'); openAuthModal(); return; }
  const myReports = reports.filter(r => r.createdBy === me.username);
  $('footprintsUser').textContent = `账号：${me.username}（${me.role === 'volunteer' ? '志愿者组织' : '公众'}）· 共 ${myReports.length} 条上报`;

  const listEl = $('footprintsList');
  if (myReports.length === 0) {
    listEl.innerHTML = '<div class="fp-empty">还没有上报记录<br>去「拍照上报」贡献第一条吧 📷</div>';
  } else {
    listEl.innerHTML = myReports.map(r => {
      const resolver = (r.resolution && r.resolution.operator)
        ? `<span class="who">${r.resolution.operator}</span>`
        : (r.history || []).filter(h => h.operator).slice(-1).map(h => `<span class="who">${h.operator}</span>`).join('') || '';
      let resolverText = '';
      if (r.status === 'resolved') {
        resolverText = resolver ? `已由 ${resolver} 解决` : '已解决';
      } else if (r.status === 'processing') {
        resolverText = resolver ? `正在处理中 · ${resolver}` : '正在处理中';
      } else {
        resolverText = '等待处理';
      }
      return `<div class="fp-card">
        <div class="fp-top">
          <span class="status-badge ${STATUS_CLS[r.status]}">${STATUS_TEXT[r.status]}</span>
          <span class="fp-cat">${r.category}</span>
        </div>
        <div class="fp-addr">📍 ${r.address || `${r.lat.toFixed(6)}, ${r.lng.toFixed(6)}`}<br>上报于 ${fmtTime(r.createdAt)}</div>
        <div class="fp-resolver">${resolverText}</div>
      </div>`;
    }).join('');
  }
  openSheet('footprintsSheet');
}

/* ---------------- 弹层控制 ---------------- */
function openSheet(id) {
  $('sheetMask').classList.remove('hidden');
  const sheet = $(id);
  sheet.classList.remove('hidden');
  requestAnimationFrame(() => sheet.classList.add('show'));
}

function closeSheetBodies() {
  ['reportSheet', 'detailSheet', 'footprintsSheet', 'resolveSheet'].forEach(id => {
    const s = $(id);
    s.classList.remove('show');
    s.classList.add('hidden');
  });
}

function closeAllSheets() {
  exitPickMode();
  clearPickMarker();
  closeSheetBodies();
  $('sheetMask').classList.add('hidden');
  currentDetail = null;
}

/* ---------------- 工具 ---------------- */
function fmtTime(iso) {
  const d = new Date(iso);
  const p = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

let toastTimer;
function toast(msg) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 2200);
}

/* ---------------- 全屏查看大图 ---------------- */
function openLightbox(src) {
  $('lightboxImg').src = src;
  $('lightbox').classList.remove('hidden');
}

function closeLightbox() {
  $('lightbox').classList.add('hidden');
  $('lightboxImg').src = '';
}
