// 南山区无障碍问题上报地图 - 后端服务
// 启动: node server.js   访问: http://localhost:3000

const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;

const DATA_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const DATA_FILE = path.join(DATA_DIR, 'reports.json');
const USER_FILE = path.join(DATA_DIR, 'users.json');

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]');
if (!fs.existsSync(USER_FILE)) fs.writeFileSync(USER_FILE, '[]');

function loadReports() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch { return []; }
}
function saveReports(list) { fs.writeFileSync(DATA_FILE, JSON.stringify(list, null, 2)); }

function loadUsers() {
  try { return JSON.parse(fs.readFileSync(USER_FILE, 'utf8')); } catch { return []; }
}
function saveUsers(list) { fs.writeFileSync(USER_FILE, JSON.stringify(list, null, 2)); }

// 会话 token 表（token -> username）。演示简单内存存储，重启后需重新登录。
const sessions = new Map();

function hashPassword(password, salt) {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}
function makeToken() {
  return crypto.randomBytes(32).toString('hex');
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, UPLOAD_DIR),
  filename: (req, file, cb) => {
    const ext = (path.extname(file.originalname || '') || '.jpg').toLowerCase();
    cb(null, `photo_${Date.now()}_${Math.random().toString(36).slice(2, 8)}${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 15 * 1024 * 1024 } });

app.use(express.json());
// 静态资源禁用缓存，确保前端改动（HTML/CSS/JS）刷新即生效
app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders: (res, filePath) => {
    if (/\.(html|css|js)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.setHeader('Pragma', 'no-cache');
      res.setHeader('Expires', '0');
    }
  }
}));
app.use('/uploads', express.static(UPLOAD_DIR));

/* ---------------- 工具：从请求提取当前登录用户 ---------------- */
function authUser(req) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  if (!token) return null;
  const username = sessions.get(token);
  if (!username) return null;
  return loadUsers().find(u => u.username === username) || null;
}

/* ---------------- 账号：注册 / 登录 / 当前用户 / 登出 ---------------- */
app.post('/api/register', (req, res) => {
  const { username = '', password = '', role = 'public', orgName = '' } = req.body;
  const name = username.trim();
  if (!name || name.length < 2) return res.status(400).json({ error: '用户名至少 2 个字符' });
  if (!password || password.length < 6) return res.status(400).json({ error: '密码至少 6 位' });
  if (!['public', 'volunteer'].includes(role)) return res.status(400).json({ error: '无效身份' });

  const users = loadUsers();
  if (users.some(u => u.username === name)) return res.status(409).json({ error: '该用户名已被注册' });

  const salt = crypto.randomBytes(16).toString('hex');
  const user = {
    username: name,
    role,
    orgName: role === 'volunteer' ? (orgName.trim() || name) : '',
    salt,
    hash: hashPassword(password, salt),
    createdAt: new Date().toISOString()
  };
  users.push(user);
  saveUsers(users);

  const token = makeToken();
  sessions.set(token, name);
  res.json({ token, user: safeUser(user) });
});

app.post('/api/login', (req, res) => {
  const { username = '', password = '' } = req.body;
  const user = loadUsers().find(u => u.username === username.trim());
  if (!user || hashPassword(password, user.salt) !== user.hash) {
    return res.status(401).json({ error: '用户名或密码错误' });
  }
  const token = makeToken();
  sessions.set(token, user.username);
  res.json({ token, user: safeUser(user) });
});

app.get('/api/me', (req, res) => {
  const user = authUser(req);
  if (!user) return res.status(401).json({ error: '未登录' });
  res.json(safeUser(user));
});

app.post('/api/logout', (req, res) => {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : '';
  sessions.delete(token);
  res.json({ ok: true });
});

function safeUser(u) {
  return { username: u.username, role: u.role, orgName: u.orgName };
}

/* ---------------- 上报数据 ---------------- */
// 获取全部上报
app.get('/api/reports', (req, res) => {
  res.json(loadReports());
});

// 新建上报（multipart: photo, lat, lng, address, category, description）
app.post('/api/reports', upload.single('photo'), (req, res) => {
  const user = authUser(req);
  if (!user) return res.status(401).json({ error: '请先登录' });

  const { lat, lng, address = '', category = '其他', description = '' } = req.body;
  const la = parseFloat(lat);
  const ln = parseFloat(lng);
  if (!isFinite(la) || !isFinite(ln)) return res.status(400).json({ error: '缺少有效坐标' });
  if (!req.file) return res.status(400).json({ error: '请上传照片' });

  const now = new Date().toISOString();
  const report = {
    id: `${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
    lat: la,
    lng: ln,
    address,
    category,
    description,
    photo: `/uploads/${req.file.filename}`,
    status: 'pending', // pending 待处理 | processing 处理中 | resolved 已解决
    createdBy: user.username,
    createdAt: now,
    updatedAt: now,
    history: [{ status: 'pending', time: now }]
  };
  const list = loadReports();
  list.unshift(report);
  saveReports(list);
  res.json(report);
});

// 更新状态（开始处理/退回待处理/重新打开）
app.patch('/api/reports/:id/status', (req, res) => {
  const user = authUser(req);
  if (!user || user.role !== 'volunteer') return res.status(403).json({ error: '仅志愿者组织可操作' });

  const { status } = req.body;
  if (!['pending', 'processing'].includes(status)) {
    return res.status(400).json({ error: '无效状态，解决请使用 /resolve 接口' });
  }
  const list = loadReports();
  const r = list.find(x => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: '未找到该上报' });

  const now = new Date().toISOString();
  const operator = user.orgName || user.username;
  r.status = status;
  r.updatedAt = now;
  r.history.push({ status, time: now, operator });
  saveReports(list);
  res.json(r);
});

// 志愿者组织提交解决结果（multipart: photo 解决后照片, solution 解决方案）
app.post('/api/reports/:id/resolve', upload.single('photo'), (req, res) => {
  const user = authUser(req);
  if (!user || user.role !== 'volunteer') return res.status(403).json({ error: '仅志愿者组织可操作' });

  const { solution = '' } = req.body;
  if (!solution.trim()) return res.status(400).json({ error: '请填写解决方案说明' });

  const list = loadReports();
  const r = list.find(x => x.id === req.params.id);
  if (!r) return res.status(404).json({ error: '未找到该上报' });

  const now = new Date().toISOString();
  const operator = user.orgName || user.username;
  r.status = 'resolved';
  r.updatedAt = now;
  r.resolution = {
    photo: req.file ? `/uploads/${req.file.filename}` : '',
    description: solution.trim(),
    operator,
    resolvedAt: now
  };
  r.history.push({ status: 'resolved', time: now, operator });
  saveReports(list);
  res.json(r);
});

// 删除上报（管理用途，仅志愿者可删除）
app.delete('/api/reports/:id', (req, res) => {
  const user = authUser(req);
  if (!user || user.role !== 'volunteer') return res.status(403).json({ error: '仅志愿者组织可操作' });
  const list = loadReports();
  const idx = list.findIndex(x => x.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: '未找到该上报' });
  const [removed] = list.splice(idx, 1);
  if (removed.photo) {
    const p = path.join(UPLOAD_DIR, path.basename(removed.photo));
    fs.unlink(p, () => {});
  }
  if (removed.resolution && removed.resolution.photo) {
    const p = path.join(UPLOAD_DIR, path.basename(removed.resolution.photo));
    fs.unlink(p, () => {});
  }
  saveReports(list);
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`✅ 南山无障碍地图服务已启动: http://localhost:${PORT}`);
});